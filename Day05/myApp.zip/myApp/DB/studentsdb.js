//2025.3.24 updates
//array of student JSON details

let students = [
    {regNo:'2021ICT78', name:'Dinithi',gender:'female',age:23,course:'IT'},
    {regNo:'2021ICT1', name:'James',age:25,gender:'male',course:'IT'},
    {regNo:'2021ICT10', name:'Rica',age:28,gender:'male',course:'IT'},
    {regNo:'2021ICT47', name:'Pavani',age:23,gender:'female',course:'IT'},
    {regNo:'2021ICT100', name:'Emily',age:18,gender:'female',course:'IT'}
]

module.exports = students;