const express =require('express')
const router =express.Router()
const  Employee= require('../models/Employee')
const { default:mongoose } = require('mongoose')

router.get('/',async(req,res)=>{
    try {
        const results=await Employee.find().populate('Dep_ID').populate('EtfID').populate('Pro_ID')
        if (results) {
            res.status(200).json(results)
        } else {
            res.status(404).send("Sorry,No Data Found !")
        }
        } catch (error) {
            console.error(error);
            res.status(500).send("Server Error !")
        }
})

router.get('/:id',async(req,res)=>{
    try {
        const results=await Employee.find().populate('EtfID')
        if (results) {
            res.status(200).json(results)
        } else {
            res.status(404).send("Sorry,No Data Found !")
        }
        } catch (error) {
            console.error(error);
            res.status(500).send("Server Error !")
        }
})
module.exports=router